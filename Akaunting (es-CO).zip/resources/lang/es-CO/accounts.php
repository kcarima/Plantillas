<?php

return [

    'account_name'          => 'Nombre de la cuenta',
    'number'                => 'Número',
    'opening_balance'       => 'Balance de cierre',
    'current_balance'       => 'Saldo actual',
    'bank_name'             => 'Nombre del Banco',
    'bank_phone'            => 'Teléfono del Banco',
    'bank_address'          => 'Dirección del Banco',
    'default_account'       => 'Cuenta Predeterminada',

];
