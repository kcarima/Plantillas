<?php

return [

    'version'               => 'Versión',
    'powered'               => 'Desarrollado por Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Software de Contabilidad Libre',

];
