<?php

return [

    'code'                  => 'Código',
    'rate'                  => 'Tasa',
    'default'               => 'Moneda Predeterminada',
    'decimal_mark'          => 'Punto decimal',
    'thousands_separator'   => 'Separador de miles',
    'precision'             => 'Precisión',
    'symbol' => [
        'symbol'            => 'Símbolo',
        'position'          => 'Posición del Símbolo',
        'before'            => 'Antes del Monto',
        'after'             => 'Después del Monto',
    ]

];
