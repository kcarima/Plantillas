<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Big Store Ecommerce Ui Kit Flat Bootstrap Responsive Website Template| Home :: w3layouts</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- cart -->
<script src="js/imagezoom.js"></script>
<script src="js/jquery.flexslider.js"></script>

<!-- cart -->
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Big Store Ecommerce Ui Kit Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Playfair+Display:400,700,900,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
<!-- script for close -->
<script>
$(document).ready(function(c) {
	$('.alert-close').on('click', function(c){
		$('.vlcone').fadeOut('slow', function(c){
			$('.vlcone').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
$('.alert-close1').on('click', function(c){
	$('.vlctwo').fadeOut('slow', function(c){
		$('.vlctwo').remove();
	});
});	  
});
</script>
<!-- //script for close -->
<script src="js/simpleCart.min.js"> </script>
</head>
<body>
<div class="content">
	<div class="container">
		<h1>BIG STORE E-COMMERCE UI KIT</h1>
		<div class="header">
			<div class="header-top">
				<div class="col-sm-4 world">
							<ul>
								<li><select class="in-drop">
									  <option>ENGLISH</option>
									  <option>JAPANESE</option>
									  <option>FRENCH</option>
									</select></li>
								<li><select class="in-drop1">
									  <option>USD</option>
									  <option>EURO</option>
									  <option>YEN</option>
									</select>
								</li>
							</ul>
				</div>
				<div class="col-sm-4 logo text-center">
					<a href="index.html">BIG STORE</a>	
				</div>
				
					<div class="col-sm-4 header-left">		
						<p class="log"><a href="#">Signup</a><span>or</span><a  href="#">Login</a></p>
							<div class="cart box_1">
								<a href="#">
								<h3> <span class="simpleCart_total"> $0.00 </span> (<span id="simpleCart_quantity" class="simpleCart_quantity"> 0 </span> items)<img src="images/cart.png" alt=""></h3>
								</a>
								<p><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>

							</div>
							<div class="clearfix"> </div>
					</div>
						<div class="clearfix"> </div>
			
			</div>

			<div class="head-top">
				<div class="col-sm-2 number">
					<span><i class="glyphicon glyphicon-headphones"></i>879-57-23</span>
				</div>
		    <div class="col-sm-8 navigation">
				<span class="menu"><img src="images/menu.png" alt=""/></span>
									<ul class="nav1">
										<li><a href="#">Man</a></li>
										<li><a href="#">Woman</a></li>
										<li><a href="#">Kids</a></li>
										<li><a href="#">Accessories</a></li>
										<li><a href="#">Sale</a>
										<li><a href="#">Brands</a></li>
										<li><a href="#">SS 2015</a></li>
									</ul>
									<!-- script for menu -->
										<script> 
											$( "span.menu" ).click(function() {
											$( "ul.nav1" ).slideToggle( 300, function() {
											 // Animation complete.
											});
											});
										</script>
									<!-- //script for menu --> 
			</div>
			<div class="col-sm-2 search">		
				<form>
						<input type="search" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}" required="">
						<input type="submit" value=" ">
				</form>
			</div>
		<div class="clearfix"> </div>
		
							
	<!---->		
		</div>

</div>
		<div class="men-banner">
			<!-- responsiveslides -->
							<script src="js/responsiveslides.min.js"></script>
								<script>
									// You can also use "$(window).load(function() {"
									$(function () {
									 // Slideshow 4
									$("#slider3,#slider4").responsiveSlides({
										auto: true,
										pager: false,
										nav: true,
										speed: 500,
										namespace: "callbacks",
										before: function () {
									$('.events').append("<li>before event fired.</li>");
									},
									after: function () {
										$('.events').append("<li>after event fired.</li>");
										}
										});
										});
								</script>
			<!-- responsiveslides -->
			<div  id="top" class="callbacks_container">
				<ul class="rslides" id="slider3">
					<li>
						<div class="banner-text">
							<h3>Every summer</h3>
							<p>has a story</p>
						</div>
					</li>
					<li>
						<div class="banner-text">
							<h3>Shop now for</h3>
							<p>new offers</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="women-banner">
			<div  id="top" class="callbacks_container">
				<ul class="rslides" id="slider4">
					<li>
						<div class="banner-text-two">
							<h3>When in doubt, wear <span>RED</span></h3>
						</div>
					</li>
					<li>
						<div class="banner-text-two">
							<h3>Woman dresses are in <span>RED</span></h3>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="banner-bottom">
			<div class="col-md-3 bottom-grid">
				<div class="bottom-pad">
					<h3 class="cart-text">New</h3>
					<a class="cart-image" href="#"><img src="images/cart.png" alt="" /></a>
					<div class="clearfix"></div>
					<div class="btm-img">
						<img src="images/pic2.jpg" alt="" />
					</div>
					<h4>kaftan with hand-knit detail</h4>
					<p>$250</p>
				</div>
			</div>
			<div class="col-md-3 bottom-grid">
				<div class="bottom-pad">
					<h3>Brooklyn Shorts</h3>
								<script>
									// You can also use "$(window).load(function() {"
									$(function () {
									 // Slideshow 4
									$("#slider5").responsiveSlides({
										auto: true,
										pager: true,
										nav: false,
										speed: 500,
										namespace: "callbacks",
										before: function () {
									$('.events').append("<li>before event fired.</li>");
									},
									after: function () {
										$('.events').append("<li>after event fired.</li>");
										}
										});
										});
								</script>
					<div  id="top" class="callbacks_container">
						<ul class="rslides" id="slider5">
							<li>
								<div class="btm-slid">
									<img src="images/pic1.jpg" alt="" />
								</div>
							</li>
							<li>
								<div class="btm-slid">
									<img src="images/pic11.jpg" alt="" />
								</div>
							</li>
						</ul>
					</div>
						<h5>Hot <span>$75</span></h5>
				</div>
			</div>
			<div class="col-md-3 bottom-grid">
				<div class="bottom-pad four">
					<h6>SALE</h6>
					<div class="shirt-img">
						<a href="#"><img src="images/pic4.jpg" alt="" /></a>
					</div>
					<h3><a href="#">STRIPED <span>POLO SHIRT</span></a></h3>
					<p><span>$26 </span>$20</p>
				</div>
			</div>
			<div class="col-md-3 bottom-grid">
				<div class="bottom-padd">
					<h6>SALE</h6>
					<div class="boy-img">
						<img src="images/pic5.jpg" alt="" />
					</div>
				</div>
				<div class="favourites">
					<ul>
						<li><a href="#small-dialog" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>quick view</a></li>
						<li><a href="#"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>save</a></li>
						<div class="clearfix"></div>
					</ul>
					<!-- pop-up-box -->
					<!-- script for pop-up-box -->
					<script type="text/javascript" src="js/modernizr.custom.min.js"></script>    
					<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
					<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!-- //script for pop-up-box -->
					<div id="small-dialog" class="mfp-hide">
						<div class="image-top">
							<img src="images/pic5.jpg" alt="" />
						</div>
					</div>
					
			<script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
			</script>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="content-btm">
			<div class="content-grids">
				<div class="col-md-6 cnt-left">
					<div class="col-md-6 cnt-grid">
						<div class="cnt-pad">
							<div class="hand-bag">
								<img src="images/pic6.jpg" alt="" />
							</div>
							<h3>Chantaco Crossover Bag</h3>
							<div class="stars-right">
								<div class="rating text-left">
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
								</div>
							</div>
							<div class="stars-btm simpleCart_shelfItem">
								<div class="item_add"><span class="item_price"><p> $1500</p></span></div>

								<div class="item_add"><span class="item_price"><a class="hvr-rectangle-out button blue" href="#">ADD TO CART</a></span></div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<div class="col-md-6 cnt-grid">
						<div class="cnt-pad">
							<div class="cnt-txt">
								<h3>Watch Goa With Silicon Strap</h3>
								<p>$1500</p>
							</div>
							<div class="hand-bag">
								<img src="images/pic7.jpg" alt="" />
							</div>
						</div>
						<a class="hvr-rectangle-out button add-cart" href="#">ADD TO CART</a>
					</div>
					<div class="clearfix"></div>
					<div class="shoe-grid">
						<div class="shoe-left">
							<img src="images/pic8.jpg" alt="" />
						</div>
						<div class="shoe-right">
							<h3>Comba Leather And Suede Trainers</h3>
							<div class="stars-right">
								<div class="rating text-left">
											
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
											<span>☆</span>
											
								</div>
							</div>
							<p>Sed ut perspiciatis unde omnis iste natus 
							error sit voluptatem accusantium doloremque 
							laudantium, totam rem aperiam, eaque ipsa quae
							ab illo inventore.</p>
							<div class="ad-crt simpleCart_shelfItem">
								<div class="item_add"><span class="item_price"><h4> $25000</h4></span></div>
								<div class="item_add"><span class="item_price"><a class="hvr-rectangle-out button" href="#">ADD TO CART</a></span></div>
								<div class="clearfix"></div>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="col-md-6 cnt-right">
					<div class="col-md-6 cnt-grid">
						<ul class="menu_drop">
							<li class="item1"><a href="#">WOMEN<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
								<ul>
									<li class="subitem1"><a href="#">Tops </a></li>
									<li class="subitem2"><a href="#"> Inner Wear</a></li>
									<li class="subitem3"><a href="#">Sarees</a></li>
								</ul>
							</li>
							<div class="clearfix"></div>
							<li class="item2"><a href="#">MEN<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
								<ul>
									<li class="subitem1"><a href="#">Suits </a></li>
									<li class="subitem2"><a href="#"> Trousers</a></li>
									<li class="subitem3"><a href="#"> Jeans</a></li>
									<li class="subitem4"><a href="#"> Shorts</a></li>
									<li class="subitem5"><a href="#"> Shirts</a></li>
									<li class="subitem6"><a href="#"> T-shirts</a></li>
									<li class="subitem7"><a href="#"> Polo</a></li>
								</ul>
							</li>
							<div class="clearfix"></div>
							<li class="item3"><a href="#">KIDS<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
								<ul>
									<li class="subitem1"><a href="#">Toys</a></li>
									<li class="subitem2"><a href="#">Dresses</a></li>
									
								</ul>
							</li>
							<div class="clearfix"></div>
							<li class="item4"><a href="#">ACCESSORIES<span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
								<ul>
									<li class="subitem1"><a href="#">Rings</a></li>
									<li class="subitem2"><a href="#"> Long NeckLace</a></li>
									<li class="subitem3"><a href="#">Chains</a></li>
								</ul>
							</li>
							<div class="clearfix"></div>
						</ul>
						<!-- script for tabs -->
							<script type="text/javascript">
								$(function() {
								
									var menu_ul = $('.menu_drop > li > ul'),
										   menu_a  = $('.menu_drop > li > a');
									
									menu_ul.hide();
								
									menu_a.click(function(e) {
										e.preventDefault();
										if(!$(this).hasClass('active')) {
											menu_a.removeClass('active');
											menu_ul.filter(':visible').slideUp('normal');
											$(this).addClass('active').next().stop(true,true).slideDown('normal');
										} else {
											$(this).removeClass('active');
											$(this).next().stop(true,true).slideUp('normal');
										}
									});
								
								});
							</script>
						<!-- script for tabs -->
						<div class="range">
							<h3 class="sear-head">PRICE</h3>
									<ul class="dropdown-menu6">
										<li>
															
											<div id="slider-range"></div>							
												<input type="text" id="amount" style="border: 0; color: #ffffff; font-weight: normal;" />
											</li>			
									</ul>
									<!---->
									<script type="text/javascript" src="js/jquery-ui.js"></script>
									<script type='text/javascript'>//<![CDATA[ 
									$(window).load(function(){
									 $( "#slider-range" ).slider({
												range: true,
												min: 0,
												max: 3000,
												values: [ 50, 1800],
												slide: function( event, ui ) {  $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
												}
									 });
									$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );

									});//]]>  

									</script>
									
						</div>
						<div class="size-grid">
							<h3>SIZE</h3>
							<ul>
								<li><a href="#">XS</a></li>
								<li><a href="#">S</a></li>
								<li><a href="#">M</a></li>
								<li><a href="#">L</a></li>
								<li><a href="#">XL</a></li>
								<li><a href="#">XXL</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-6 cnt-grid-rt">
						<div class="cnt-gd-rt-back">
							<h3>COLORS</h3>
							<ul>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>
						<div class="cnt-gd-rt-bottom">
							<h3>COLORS</h3>
							<div class="login-bottom">
								<div class="checkbox-form">
									<div class="check">
										<label class="checkbox"><p class="green"></p><h6></h6><input type="checkbox" name="checkbox" checked=""><i> </i>Black</label>
									</div>
									<div class="check">
										<label class="checkbox"><p class="red"></p><h6></h6><input type="checkbox" name="checkbox" checked=""><i> </i>Dark gray</label>
									</div>
									<div class="check">
										<label class="checkbox"><p class="yellow"></p><h6></h6><input type="checkbox" name="checkbox" checked=""><i> </i>Lime green</label>
									</div>
								
								</div>
							</div>
						</div>
						<div class="shower-gel">
							<div class="shower-img">
								<img src="images/mark.jpg" alt="" />
							</div>
							<ul>
								<li>
									<div class="shower-left">
										<img src="images/pic9.jpg" alt="" />
									</div>
									<div class="shower-right">
										<h4>Shower Gel Eau De lacoste L.12.12 Jaune 150ML</h4>
										<p>$30</p>
									</div>
									<div class="clearfix"></div>
								</li>
								<li>
									<div class="shower-left">
										<img src="images/pic10.jpg" alt="" />
									</div>
									<div class="shower-right">
										<h4>Eau De lacoste L.12.12 Rouge 30ML</h4>
										<p>$150</p>
									</div>
									<div class="clearfix"></div>
								</li>
								<li class="text-center">
									<p>Total: <span>$180</span></p>
									<a href="#">CHECKOUT</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="shoe-slider">
			<div class="grid images_3_of_2">
					<div class="flexslider">
							        <!-- FlexSlider -->
										
										<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

										<script>
										// Can also be used with $(document).ready()
										$(window).load(function() {
										  $('.flexslider').flexslider({
											animation: "slide",
											controlNav: "thumbnails"
										  });
										});
										</script>
									<!-- //FlexSlider-->
							  <ul class="slides">
								<li data-thumb="images/d6.jpg">
									 <div class="thumb-image"> <img src="images/d6.jpg" data-imagezoom="true" class="img-responsive"> </div>
								</li>
								<li data-thumb="images/d8.jpg">
								   <div class="thumb-image"> <img src="images/d8.jpg" data-imagezoom="true" class="img-responsive"> </div>
								</li>
								<li data-thumb="images/d5.jpg">
									<div class="thumb-image"> <img src="images/d5.jpg" data-imagezoom="true" class="img-responsive"> </div>
								</li>
								
								<li data-thumb="images/d7.jpg">
								   <div class="thumb-image"> <img src="images/d7.jpg" data-imagezoom="true" class="img-responsive"> </div>
								</li>
								
							  </ul>
							<div class="clearfix"></div>
					</div>	
			</div>
			<div class="grid images_3_1">
				<h4>SHOES</h4>
				<h3>Marice Canvas Trainers</h3>
				<h5>REF. 2597/399</h5>
					<div class="doll-gd simpleCart_shelfItem">
						
						<div class="item_add"><span class="item_price"><p> $250</p></span></div>
						<div class="item_add"><span class="item_price"><a class="hvr-rectangle-out button blue" href="#">ADD TO CART</a></span></div>
						
						<div class="clearfix"></div>
					</div>
						<div class="cnt-gd-rt-col">
							<h6>Colors</h6>
							<ul>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
							<div class="clearfix"></div>
						</div>
						<div class="cnt-gd-siz">
							<h6>Select Size</h6>
							<ul>
								<li><a href="#">35.5</a></li>
								<li><a href="#">36</a></li>
								<li><a href="#">37</a></li>
								<li><a href="#">38</a></li>
								<li><a href="#">39</a></li>
								<li><a href="#">39.5</a></li>
							</ul>
							<p><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span>Size guide</p>
						</div>
						<div class="grid_3 grid_5">
						    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
								<ul id="myTab" class="nav nav-tabs" role="tablist">
								  <li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Description</a></li>
								  <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">Shipping</a></li>
								  <li role="presentation"><a href="#return" role="tab" id="return-tab" data-toggle="tab" aria-controls="return">Return</a></li>
								</ul>
								<div id="myTabContent" class="tab-content">
								  <div role="tabpanel" class="tabs-para tab-pane fade in active" id="home" aria-labelledby="home-tab">
									<p>Sed ut perspiciatis unde 
									omnis iste natus error sit 
									voluptatem accusantium doloremque
									laudantium, totam rem aperiam. </p>
									<ul>
										<li><a href="#">Perspiciatis unde omnis.</a></li>
										<li><a href="#">Totam rem aperiam, eaque.</a></li>
										<li><a href="#">Accusantium doloremque.</a></li>
										<li><a href="#">Inventore veritatis.</a></li>
									</ul>
								  </div>
								  <div role="tabpanel" class="tabs-para tab-pane fade" id="profile" aria-labelledby="profile-tab">
									<p>Food truck fixie locavore, accusamus mcsweeney's 
									marfa nulla single-origin coffee squid. 
									Exercitation +1 labore velit, blog sartorial  
									four loko farm-to-table craft beer twee. Qui photo booth letterpress.</p>
								  </div>
								  <div role="tabpanel" class="tabs-para tab-pane fade" id="return" aria-labelledby="return-tab">
									<p>Nulla single-origin coffee squid. 
									Exercitation +1 labore velit, blog 
									sartorial PBR leggings next level wes
									anderson artisan four.</p>
									<ul>
										<li><a href="#">Perspiciatis unde omnis.</a></li>
										<li><a href="#">Totam rem aperiam, eaque.</a></li>
										<li><a href="#">Accusantium doloremque.</a></li>
										<li><a href="#">Inventore veritatis.</a></li>
									</ul>

								  </div>
								</div>
							</div>
						</div>

			</div>
			<div class="clearfix"></div>
		</div>
		<div class="product-easy">
					<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
						<script type="text/javascript">
							$(document).ready(function () {
								$('#horizontalTab').easyResponsiveTabs({
									type: 'default', //Types: default, vertical, accordion           
									width: 'auto', //auto or any width like 600px
									fit: true   // 100% fit in a container
								});
							});
							
						</script>
						<div class="sap_tabs">
							<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
								  <ul class="resp-tabs-list">
									  <li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>Cart</span></li> 
									  <li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>Shipping</span></li> 
									  <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>Payment</span></li> 
								  </ul>				  	 
								<div class="resp-tabs-container">
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
										<div class="tab-img">
											<div class="quantity-grids">
												<div class="qua_gd_1">
													<h3>PRODUCT</h3>
												</div>
												<div class="qua_gd_2">
													<h3>DESCRIPTION</h3>
												</div>
												<div class="qua_gd_3">
													<h3>COLOR</h3>
												</div>
												<div class="qua_gd_4">
													<h3>SIZE</h3>
												</div>
												<div class="qua_gd_5">
													<h3>QUANTITY</h3>
												</div>
												<div class="qua_gd_6">
													<h3>AMOUNT</h3>
												</div>
												<div class="clearfix"></div>
											</div>
											<div class="qua-bot vlcone">
												<div class="alert-close"> </div>
												<div class="qua_gd_1">
													<img src="images/d6.jpg" alt="" />
												</div>
												<div class="qua_gd_2">
													<h4>Marice Canvas Trainers</h4>
													<p>REF.2597/399</p>
												</div>
												<div class="qua_gd_3">
													<h4><span></span>Desaturated blue</h4>
												</div>
												<div class="qua_gd_4">
													<h4>37</h4>
												</div>
												<div class="qua_gd_5">
													<h4>1</h4>
												</div>
												<div class="qua_gd_6">
													<h4>$250</h4>
												</div>
												<div class="clearfix"></div>
											</div>
											<div class="qua-bot vlctwo">
												<div class="alert-close1"> </div>
												<div class="qua_gd_1">
													<img src="images/pic2.jpg" alt="" />
												</div>
												<div class="qua_gd_2">
													<h4>Marice Canvas Trainers</h4>
													<p>REF.2597/399</p>
												</div>
												<div class="qua_gd_3">
													<h4><span></span>Desaturated blue</h4>
												</div>
												<div class="qua_gd_4">
													<h4>M</h4>
												</div>
												<div class="qua_gd_5">
													<h4>1</h4>
												</div>
												<div class="qua_gd_6">
													<h4>$500</h4>
												</div>
												<div class="clearfix"></div>
											</div>
											<a href="#" class="hvr-rectangle-in button red">BACK TO CART</a>
											<a href="#" class="hvr-rectangle-out button blue">CONTINUE</a>
											<div class="clearfix"></div>
										</div>
									</div>
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
										<div class="tab-img">
											<form>
												<h5>COUNTRY</h5>	
												<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">

												<div class="tab-forms">
													<div class="tab-form-left">
														<h5>FIRST NAME</h5>
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="tab-form-right">
														<h5>LAST NAME</h5>													
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="clearfix"></div>
												</div>
												<h5>COMPANY NAME</h5>	
												<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
												<h5>ADDRESS</h5>	
												<input type="text" value="Street address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Street address';}" required="">
												<input type="text" value="Apartment,suite,unit etc." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Apartment,suite,unit etc.';}" required="">
												<h5>TOWN/CITY</h5>	
												<input type="text" value="">
												<div class="tab-forms">
													<div class="tab-form-left">
														<h5>STATE/COUNTRY</h5>
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="tab-form-right">
														<h5>POSTCODE/ZIP</h5>													
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="clearfix"></div>
												</div>
												<div class="tab-forms">
													<div class="tab-form-left">
														<h5>E-MAIL ADDRESS</h5>
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="tab-form-right">
														<h5>PHONE</h5>													
														<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
													</div>
													<div class="clearfix"></div>
												</div>
											</form> 
											<a href="#" class="hvr-rectangle-in button red">BACK TO CART</a>
											<a href="#" class="hvr-rectangle-out button blue">CONTINUE</a>
											<div class="clearfix"></div>
										</div>
									</div>
									<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">
										<div class="tab_grid_6">
											<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
												<ul id="myTab" class="nav nav-tabs text-center" role="tablist">
												  <li role="presentation" class="active"><a href="#bank" id="bank-tab" role="tab1" data-toggle="tab" aria-controls="bank" aria-expanded="true">BANK TRANFER</a></li>
												  <li role="presentation"><a href="#cheque" role="tab1" id="cheque-tab" data-toggle="tab" aria-controls="cheque">CHEQUE</a></li>
												  <li role="presentation"><a href="#card" role="tab1" id="card-tab" data-toggle="tab" aria-controls="card">CARD</a></li>
												</ul>
												<div id="myTabContent" class="tab-content">
												  <div role="tabpanel" class="tabs-para-two tab-pane fade in active" id="bank" aria-labelledby="bank-tab">
														<div class="cheque-form">
															<form>
																<h3>From Account</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>amount</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>Beneficiary bank </h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>payment type</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>to open beneficiary account</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>beneficiary name</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>beneficiary id</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>transaction reference no.</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<h3>description of transaction</h3>
																<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">
																<button class="btn1">Submit</button>
															</form>
														</div>
												  </div>
												  <div role="tabpanel" class="tabs-para-two tab-pane fade" id="cheque" aria-labelledby="cheque-tab">
														<div class="cheque-form">
															<form>
																<h3>Deposited in</h3>
																<input type="text" value="Branch Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Branch Name';}" required="">
																<h3>A/C hold in</h3>
																<input type="text" value="Branch Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Branch Name';}" required="">
																<h3>Name of the A/C holder</h3>
																<input type="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}" required="">
																<h3>A/C no.</h3>
																<input type="text" value="Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Number';}" required="">
																<h3>mobile no. (Preferably in India)</h3>
																<input type="text" value="Mobile Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Mobile Number';}" required="">
																<h3>Tel no.</h3>
																<input type="text" value="Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Number';}" required="">
																<p> Neque porro quisquam est, qui dolorem ipsum quia dolor
																sit amet, consectetur, adipisci velit, sed quia non numquam 
																eius modi tempora incidunt ut labore et dolore magnam aliquam.</p>
															</form>
														</div>
												  </div>
												  <div role="tabpanel" class="tabs-para-two tab-pane fade" id="card" aria-labelledby="card-tab">
													<div class="tab-img">
														<form>
															<div class="tab-for">
																<div class="tab-form-left">
																	<h5>CARDHOLDER'S NAME</h5>
																	<input type="text" value="">
																</div>
																<div class="tab-form-right">
																	<h5>CREDIT CARD NUMBER</h5>													
																	<input type="text" value="">
																</div>
																<div class="clearfix"></div>
																<div class="tab-form-left user-form">
																	<h5>EXPIRATION</h5>
																	<ul>
																		<li>
																			<input type="number" class="text_box" type="text" value="6" min="1" />	
																		</li>
																		<li>
																			<input type="number" class="text_box" type="text" value="1988" min="1" />	
																		</li>
																		<div class="clearfix"></div>
																	</ul>
																</div>
																<div class="tab-form-right user-form-rt">
																	<h5>CVC / CVV</h5>													
																	<input type="text" value="">
																</div>
																<div class="clearfix"></div>
															</div>
														</form>
															<a href="#" class="hvr-rectangle-in button red">BACK TO SHIPPING</a>
															<a href="#" class="hvr-rectangle-out button blue">CHECK OUT</a>
															<div class="clearfix"></div>
													</div>
												  </div>
												</div>
											</div>
										</div>		        					 
									</div>	
								</div>	
							</div>
						</div>


		</div>
		<div class="footer">
			<div class="footer-one">
				<h2><a href="#">BIG STORE</a></h2>
				<p>&copy; 2016 Big store. All Rights Reserved | Template by <a href="http://w3layouts.com/"> W3layouts</a></p>
			</div>
			<div class="footer-two">
				<h4>MAN</h4>
				<ul>
					<li><a href="#">Jackets</a></li>
					<li><a href="#">Blazers</a></li>
					<li><a href="#">Suits</a></li>
					<li><a href="#">Trousers</a></li>
					<li><a href="#">Jeans</a></li>
				</ul>
				<ul>
					<li><a href="#">Denim</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Shirts</a></li>
					<li><a href="#">T-shirts</a></li>
					<li><a href="#">Polo</a></li>
				</ul>
			</div>
			<div class="footer-two">
				<h4>WOMAN</h4>
				<ul>
					<li><a href="#">Coats</a></li>
					<li><a href="#">Jackets</a></li>
					<li><a href="#">Dresses</a></li>
					<li><a href="#">Jumpsuits</a></li>
					<li><a href="#">Tops</a></li>
				</ul>
				<ul>
					<li><a href="#">Leather</a></li>
					<li><a href="#">Trousers</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Jeans</a></li>
					<li><a href="#">Denim</a></li>
				</ul>
			</div>
			<div class="footer-three">
				<h4>KID</h4>
				<ul>
					<li><a href="#">Girl</a></li>
					<li><a href="#">Boy</a></li>
					<li><a href="#">Baby girl</a></li>
					<li><a href="#">Baby boy</a></li>
					<li><a href="#">Min</a></li>
				</ul>
			</div>
			<div class="footer-three">
				<h4>SHOES & BAGS</h4>
				<ul>
					<li><a href="#">Woman</a></li>
					<li><a href="#">Man</a></li>
					<li><a href="#">Girl</a></li>
					<li><a href="#">Boy</a></li>
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>	
</div>

<script src="js/bootstrap.js"></script>
</body>
</html>